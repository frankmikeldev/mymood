(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion-dom_dist_es_bc6a3e4a._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1c28304b._.js",
  "static/chunks/node_modules_next_a93b0a1c._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_f8ab58b4._.js",
  "static/chunks/_8bb19e91._.js"
],
    source: "dynamic"
});
