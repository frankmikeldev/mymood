(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_util_5bf7d2cb._.js",
  "static/chunks/node_modules_recharts_es6_state_31236a24._.js",
  "static/chunks/node_modules_recharts_es6_component_ed2fe469._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_9cb3e3ec._.js",
  "static/chunks/node_modules_recharts_es6_5fd94a46._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_b00a18bb._.js",
  "static/chunks/node_modules_@supabase_9951646f._.js",
  "static/chunks/node_modules_fdefd612._.js",
  "static/chunks/_18aa58bd._.js"
],
    source: "dynamic"
});
